from setuptools import find_packages, setup

setup(
    name="music_classification",
    packages=find_packages(),
    version="1.0.0",
    description="Project done for the Pattern Recognition class",
    author="Elmer, Rita",
    license="",
)
